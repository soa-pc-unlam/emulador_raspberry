# Simu

Este paquete sirve para poder ejecutar un simulador de los GPIO de la Raspberry PI en una PC. Este forma parte de un programa Cliente-Servidor de Pigpio . Por un lado el servidor se ejecuta dentro de un contendor Docker, mientras que por otro el cliente se debe ejecutar en el host importando este paquete en los scripts de Python que usan los GPIO de la Raspberry en la PC.
